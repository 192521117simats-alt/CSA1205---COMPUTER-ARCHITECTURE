# CSA1205: Pipeline Processor Simulation & Data Hazard Project

## Project Overview
This project models a 5-stage RISC pipeline architecture (IF, ID, EX, MEM, WB) evaluating RAW (Read-After-Write) data hazard handling, forwarding unit dynamics, and memory hierarchy stalls.

## Features
- **Hazard Detection Unit:** Detects load-use dependencies and injects pipeline bubbles automatically.
- **Forwarding Logic:** Supports `EX/MEM -> EX` and `MEM/WB -> EX` operand bypassing.
- **Cache Modeling:** Calculates total cycles under L1 cache miss penalties.

## Build and Run Instructions
1. Open terminal in project root directory.
2. Compile project:
   ```bash
   g++ -g src/pipeline_sim.cpp -o build/pipeline_sim.exe