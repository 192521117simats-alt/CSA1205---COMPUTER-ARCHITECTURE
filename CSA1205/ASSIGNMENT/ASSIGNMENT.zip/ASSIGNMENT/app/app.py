from flask import Flask, render_template, jsonify

app = Flask(__name__)

def run_simulation(instructions, l1_miss_rate=0.10):
    # Pipeline simulation logic returning JSON trace
    cycles = []
    pc = 0
    cycle = 0
    load_use_stalls = 0
    retired = 0
    
    # Simple cycle-accurate state tracker
    IF_ID, ID_EX, EX_MEM, MEM_WB = None, None, None, None
    stall_next = False
    
    while retired < len(instructions) and cycle < 20:
        cycle += 1
        note = ""

        if MEM_WB and not MEM_WB.get("is_bubble"):
            retired += 1

        MEM_WB = EX_MEM

        load_use_hazard = False
        if ID_EX and not ID_EX.get("is_bubble") and ID_EX.get("type") == "LOAD":
            if IF_ID and not IF_ID.get("is_bubble"):
                if ID_EX.get("dest") in [IF_ID.get("src1"), IF_ID.get("src2")]:
                    load_use_hazard = True

        if load_use_hazard and not stall_next:
            EX_MEM = {"id": "BUBBLE", "is_bubble": True}
            stall_next = True
            load_use_stalls += 1
            note = "Load-Use Hazard (Stall/Bubble Injected)"
        else:
            EX_MEM = ID_EX
            ID_EX = IF_ID

            if stall_next:
                stall_next = False
            elif pc < len(instructions):
                IF_ID = instructions[pc]
                pc += 1
            else:
                IF_ID = None

            if ID_EX and not ID_EX.get("is_bubble") and ID_EX.get("type") == "ALU":
                if EX_MEM and not EX_MEM.get("is_bubble") and EX_MEM.get("dest") != -1:
                    if EX_MEM.get("dest") in [ID_EX.get("src1"), ID_EX.get("src2")]:
                        note = "Forwarding: EX/MEM -> EX"
                elif MEM_WB and not MEM_WB.get("is_bubble") and MEM_WB.get("dest") != -1:
                    if MEM_WB.get("dest") in [ID_EX.get("src1"), ID_EX.get("src2")]:
                        note = "Forwarding: MEM/WB -> EX"

        cycles.append({
            "cycle": cycle,
            "IF": IF_ID.get("id") if IF_ID and not IF_ID.get("is_bubble") else "-",
            "ID": ID_EX.get("id") if ID_EX and not ID_EX.get("is_bubble") else "-",
            "EX": "BUBBLE" if EX_MEM and EX_MEM.get("is_bubble") else (EX_MEM.get("id") if EX_MEM else "-"),
            "MEM": "BUBBLE" if MEM_WB and MEM_WB.get("is_bubble") else (MEM_WB.get("id") if MEM_WB else "-"),
            "WB": MEM_WB.get("id") if MEM_WB and not MEM_WB.get("is_bubble") else "-",
            "note": note
        })

    n = len(instructions)
    cpi_b = round(cycle / n, 2)
    expected_c = round(cycle + (1 * l1_miss_rate * 8), 2)
    cpi_c = round(expected_c / n, 2)
    speedup = round(20.0 / expected_c, 2)

    return {
        "cycles": cycles,
        "metrics": {
            "total_cycles": cycle,
            "stalls": load_use_stalls,
            "cpi_forwarding": cpi_b,
            "cpi_cache": cpi_c,
            "speedup": speedup
        }
    }

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/simulate", methods=["POST"])
def simulate():
    default_benchmark = [
        {"id": "I1", "text": "LW R1, 0(R2)", "type": "LOAD", "dest": 1, "src1": 2, "src2": -1},
        {"id": "I2", "text": "ADD R4, R1, R5", "type": "ALU", "dest": 4, "src1": 1, "src2": 5},
        {"id": "I3", "text": "SUB R6, R4, R7", "type": "ALU", "dest": 6, "src1": 4, "src2": 7},
        {"id": "I4", "text": "AND R8, R6, R9", "type": "ALU", "dest": 8, "src1": 6, "src2": 9},
        {"id": "I5", "text": "OR R10, R8, R11", "type": "ALU", "dest": 10, "src1": 8, "src2": 11},
        {"id": "I6", "text": "ADD R12, R10, R13", "type": "ALU", "dest": 12, "src1": 10, "src2": 13}
    ]
    data = run_simulation(default_benchmark)
    return jsonify(data)

if __name__ == "__main__":
    app.run(debug=True, port=5000)