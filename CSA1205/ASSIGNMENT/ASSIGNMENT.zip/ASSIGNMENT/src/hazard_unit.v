// Hazard Detection Unit for 5-Stage RISC Pipeline
module hazard_detection_unit (
    input wire [4:0] id_ex_rd,
    input wire id_ex_mem_read, // 1 if ID/EX instruction is LW
    input wire [4:0] if_id_rs1,
    input wire [4:0] if_id_rs2,
    output reg pc_write,
    output reg if_id_write,
    output reg control_mux_zero // Inject bubble (stall)
);
    always @(*) begin
        // Check for Load-Use Data Hazard
        if (id_ex_mem_read && ((id_ex_rd == if_id_rs1) || (id_ex_rd == if_id_rs2))) begin
            pc_write         = 1'b0; // Freeze PC counter
            if_id_write      = 1'b0; // Freeze IF/ID register
            control_mux_zero = 1'b1; // Inject bubble into EX stage
        end else begin
            pc_write         = 1'b1; // Normal pipeline operation
            if_id_write      = 1'b1;
            control_mux_zero = 1 me'b0;
        end
    end
endmodule