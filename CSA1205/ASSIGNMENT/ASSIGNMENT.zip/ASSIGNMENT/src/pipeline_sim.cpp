#include <iostream>
#include <vector>
#include <string>
#include <iomanip>

// 1. Instruction & Control Signal Structures
struct Instruction {
    std::string id;
    std::string asm_text;
    int opcode; // 0: ALU, 1: LOAD, 2: STORE
    int rd;
    int rs1;
    int rs2;
};

// Inter-stage Pipeline Registers
struct IF_ID_Reg {
    Instruction instr;
    bool valid = false;
};

struct ID_EX_Reg {
    Instruction instr;
    int val_rs1 = 0;
    int val_rs2 = 0;
    bool reg_write = false;
    bool mem_read = false;
    bool valid = false;
};

struct EX_MEM_Reg {
    Instruction instr;
    int alu_result = 0;
    int write_val = 0;
    int rd = 0;
    bool reg_write = false;
    bool mem_read = false;
    bool valid = false;
};

struct MEM_WB_Reg {
    Instruction instr;
    int final_val = 0;
    int rd = 0;
    bool reg_write = false;
    bool valid = false;
};

// 2. Hardware Unit Implementations
class HardwarePipeline {
private:
    std::vector<Instruction> imem;
    int dmem[1024] = {0};
    int regfile[32] = {0};
    
    int pc = 0;
    int cycle = 0;
    int load_use_stalls = 0;
    int retired = 0;

    // Pipeline Registers
    IF_ID_Reg IF_ID;
    ID_EX_Reg ID_EX;
    EX_MEM_Reg EX_MEM;
    MEM_WB_Reg MEM_WB;

    // Control Signals
    bool pc_write = true;
    bool if_id_write = true;
    bool inject_bubble = false;

    // Forwarding MUX Select Signals (00: RegFile, 10: EX/MEM, 01: MEM/WB)
    int forward_a = 00;
    int forward_b = 00;

public:
    HardwarePipeline(const std::vector<Instruction>& program) : imem(program) {
        // Initialize registers for demonstration
        for (int i = 0; i < 32; ++i) regfile[i] = i * 10;
        dmem[0] = 42; // Pre-load memory address 0 with data
    }

    void evaluate_hazard_unit() {
        // Load-Use Data Hazard Detection Logic
        if (ID_EX.valid && ID_EX.mem_read && (ID_EX.instr.rd != 0)) {
            if (IF_ID.valid && (ID_EX.instr.rd == IF_ID.instr.rs1 || ID_EX.instr.rd == IF_ID.instr.rs2)) {
                pc_write = false;         // Freeze PC
                if_id_write = false;      // Freeze IF/ID Pipeline Register
                inject_bubble = true;     // Inject Stall Bubble into ID/EX
                return;
            }
        }
        pc_write = true;
        if_id_write = true;
        inject_bubble = false;
    }

    void evaluate_forwarding_unit() {
        forward_a = 0; // Default: Read from RegFile
        forward_b = 0;

        if (ID_EX.valid) {
            // Forward A Logic (RS1)
            if (EX_MEM.valid && EX_MEM.reg_write && (EX_MEM.rd != 0) && (EX_MEM.rd == ID_EX.instr.rs1)) {
                forward_a = 2; // Forward from EX/MEM
            } else if (MEM_WB.valid && MEM_WB.reg_write && (MEM_WB.rd != 0) && (MEM_WB.rd == ID_EX.instr.rs1)) {
                forward_a = 1; // Forward from MEM/WB
            }

            // Forward B Logic (RS2)
            if (EX_MEM.valid && EX_MEM.reg_write && (EX_MEM.rd != 0) && (EX_MEM.rd == ID_EX.instr.rs2)) {
                forward_b = 2; // Forward from EX/MEM
            } else if (MEM_WB.valid && MEM_WB.reg_write && (MEM_WB.rd != 0) && (MEM_WB.rd == ID_EX.instr.rs2)) {
                forward_b = 1; // Forward from MEM/WB
            }
        }
    }

    void step_cycle() {
        cycle++;
        std::string event_note = "";

        // --- STAGE 5: WRITE BACK (WB) ---
        if (MEM_WB.valid) {
            if (MEM_WB.reg_write && MEM_WB.rd != 0) {
                regfile[MEM_WB.rd] = MEM_WB.final_val;
            }
            retired++;
        }

        // --- STAGE 4: MEMORY ACCESS (MEM) ---
        MEM_WB_Reg next_MEM_WB;
        if (EX_MEM.valid) {
            next_MEM_WB.instr = EX_MEM.instr;
            next_MEM_WB.rd = EX_MEM.rd;
            next_MEM_WB.reg_write = EX_MEM.reg_write;
            next_MEM_WB.valid = true;

            if (EX_MEM.mem_read) {
                next_MEM_WB.final_val = dmem[EX_MEM.alu_result % 1024]; // Memory Read
            } else {
                next_MEM_WB.final_val = EX_MEM.alu_result;
            }
        } else {
            next_MEM_WB.valid = false;
        }

        // Evaluate Forwarding Unit Logic
        evaluate_forwarding_unit();

        // --- STAGE 3: EXECUTE (EX) ---
        EX_MEM_Reg next_EX_MEM;
        if (ID_EX.valid) {
            next_EX_MEM.instr = ID_EX.instr;
            next_EX_MEM.rd = ID_EX.instr.rd;
            next_EX_MEM.reg_write = ID_EX.reg_write;
            next_EX_MEM.mem_read = ID_EX.mem_read;
            next_EX_MEM.valid = true;

            // Resolve Operand A with Forwarding MUX
            int op_a = ID_EX.val_rs1;
            if (forward_a == 2) {
                op_a = EX_MEM.alu_result;
                event_note += "[Fwd EX/MEM->A] ";
            } else if (forward_a == 1) {
                op_a = MEM_WB.final_val;
                event_note += "[Fwd MEM/WB->A] ";
            }

            // Resolve Operand B with Forwarding MUX
            int op_b = ID_EX.val_rs2;
            if (forward_b == 2) {
                op_b = EX_MEM.alu_result;
                event_note += "[Fwd EX/MEM->B] ";
            } else if (forward_b == 1) {
                op_b = MEM_WB.final_val;
                event_note += "[Fwd MEM/WB->B] ";
            }

            // Execute ALU Operation
            if (ID_EX.instr.opcode == 1) { // LOAD
                next_EX_MEM.alu_result = op_a + 0; // Immediate Offset
            } else { // ALU ADD/SUB
                next_EX_MEM.alu_result = op_a + op_b;
            }
        } else {
            next_EX_MEM.valid = false;
        }

        // Evaluate Hazard Unit Logic
        evaluate_hazard_unit();

        // --- STAGE 2: INSTRUCTION DECODE (ID) ---
        ID_EX_Reg next_ID_EX;
        if (inject_bubble) {
            next_ID_EX.valid = false; // Inject Bubble
            load_use_stalls++;
            event_note = "STALL (Load-Use Hazard Detected)";
        } else if (IF_ID.valid) {
            next_ID_EX.instr = IF_ID.instr;
            next_ID_EX.val_rs1 = regfile[IF_ID.instr.rs1];
            next_ID_EX.val_rs2 = regfile[IF_ID.instr.rs2];
            next_ID_EX.reg_write = (IF_ID.instr.rd != 0);
            next_ID_EX.mem_read = (IF_ID.instr.opcode == 1);
            next_ID_EX.valid = true;
        } else {
            next_ID_EX.valid = false;
        }

        // --- STAGE 1: INSTRUCTION FETCH (IF) ---
        IF_ID_Reg next_IF_ID = IF_ID;
        if (pc_write) {
            if (pc < (int)imem.size()) {
                next_IF_ID.instr = imem[pc++];
                next_IF_ID.valid = true;
            } else {
                next_IF_ID.valid = false;
            }
        }

        // Pipeline Register Transfers
        MEM_WB = next_MEM_WB;
        EX_MEM = next_EX_MEM;
        if (!inject_bubble) {
            ID_EX = next_ID_EX;
            IF_ID = next_IF_ID;
        } else {
            ID_EX.valid = false; // Inject bubble into EX
        }

        // Print Cycle State Trace
        std::cout << std::left << std::setw(8) << cycle
                  << std::setw(10) << (IF_ID.valid ? IF_ID.instr.id : "-")
                  << std::setw(10) << (ID_EX.valid ? ID_EX.instr.id : "-")
                  << std::setw(10) << (EX_MEM.valid ? EX_MEM.instr.id : "-")
                  << std::setw(10) << (MEM_WB.valid ? MEM_WB.instr.id : "-")
                  << std::setw(10) << (MEM_WB.valid ? "RETIRE" : "-")
                  << event_note << "\n";
    }

    void run() {
        std::cout << "\n========================================================================\n";
        std::cout << "               HARDWARE PIPELINE RTL EXECUTION TRACE                    \n";
        std::cout << "========================================================================\n";
        std::cout << std::left << std::setw(8) << "Cycle"
                  << std::setw(10) << "IF"
                  << std::setw(10) << "ID"
                  << std::setw(10) << "EX"
                  << std::setw(10) << "MEM"
                  << std::setw(10) << "WB"
                  << "Hardware Control & Hazard Notes\n";
        std::cout << "------------------------------------------------------------------------\n";

        while (retired < (int)imem.size() && cycle < 20) {
            step_cycle();
        }

        print_metrics();
    }

    void print_metrics() {
        int n = imem.size();
        double cpi_b = (double)cycle / n;
        double expected_c = cycle + (1 * 0.10 * 8); // 1 load, 10% miss, 8 cycle penalty
        double cpi_c = expected_c / n;
        double speedup = 20.0 / expected_c;

        std::cout << "\n========================================================================\n";
        std::cout << "                 HARDWARE METRICS & VALIDATION REPORT                   \n";
        std::cout << "========================================================================\n";
        std::cout << "  - Total Execution Cycles : " << cycle << " cycles (Target: 11)\n";
        std::cout << "  - Unavoidable Bubble     : " << load_use_stalls << " stall cycle\n";
        std::cout << "  - Scenario B CPI         : " << std::fixed << std::setprecision(2) << cpi_b << " (Target: 1.83)\n";
        std::cout << "  - Scenario C CPI (10% L1): " << cpi_c << " (Target: 1.97)\n";
        std::cout << "  - Overall Speedup vs 20c : " << speedup << "x (Target: 1.69x)\n";
        std::cout << "========================================================================\n\n";
    }
};

int main() {
    std::vector<Instruction> benchmark = {
        {"I1", "LW R1, 0(R2)",     1, 1, 2, -1},
        {"I2", "ADD R4, R1, R5",    0, 4, 1,  5},
        {"I3", "SUB R6, R4, R7",    0, 6, 4,  7},
        {"I4", "AND R8, R6, R9",    0, 8, 6,  9},
        {"I5", "OR R10, R8, R11",   0, 10, 8, 11},
        {"I6", "ADD R12, R10, R13", 0, 12, 10, 13}
    };

    HardwarePipeline core(benchmark);
    core.run();

    return 0;
}