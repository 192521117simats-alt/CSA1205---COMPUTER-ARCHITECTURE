import pandas as pd

BASELINE_FILE = "baseline_data.csv"
WORKLOAD_FILE = "workload_data.csv"
OUTPUT_FILE = "ml_dataset.csv"


print("=" * 65)
print("PREPARING REAL ML DATASET")
print("=" * 65)


# Load real measurements
baseline = pd.read_csv(BASELINE_FILE)
workload = pd.read_csv(WORKLOAD_FILE)


# Add experiment labels
baseline["Experiment"] = "Baseline"
workload["Experiment"] = "Controlled_Workload"


# Combine datasets
df = pd.concat(
    [baseline, workload],
    ignore_index=True
)


# ---------------------------------------------------------
# Create workload classes from ACTUAL CPU measurements
# ---------------------------------------------------------

def classify_workload(cpu):

    if cpu < 10:
        return "LOW"

    elif cpu < 40:
        return "MODERATE"

    elif cpu < 70:
        return "HIGH"

    else:
        return "VERY_HIGH"


df["Workload"] = df["CPU_Usage"].apply(classify_workload)


# Save combined dataset
df.to_csv(OUTPUT_FILE, index=False)


print("\nDataset preparation complete.")

print(f"Baseline samples          : {len(baseline)}")
print(f"Controlled workload       : {len(workload)}")
print(f"Total samples             : {len(df)}")

print("\nWorkload distribution:")
print(df["Workload"].value_counts())

print("\nCPU statistics:")
print(df["CPU_Usage"].describe())

print(f"\n✅ ML dataset saved as: {OUTPUT_FILE}")