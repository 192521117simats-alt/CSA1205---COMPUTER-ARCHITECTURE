import os
import time
import joblib
import psutil
import pandas as pd
from datetime import datetime


MODEL_FILE = "models/workload_model.pkl"
LOG_FILE = "reports/ai_decision_log.csv"


FEATURES = [
    "CPU_Usage",
    "Memory_Usage",
    "CPU_Frequency",
    "CPU_Min_Frequency",
    "CPU_Max_Frequency",
    "Physical_Cores",
    "Logical_Cores",
    "Process_Count",
    "Disk_Usage",
    "Network_Bytes_Sent",
    "Network_Bytes_Received"
]


class AIOptimizationEngine:

    def __init__(self):

        print("=" * 70)
        print("AI OPTIMIZATION ENGINE")
        print("=" * 70)

        if not os.path.exists(MODEL_FILE):
            raise FileNotFoundError(
                f"AI model not found: {MODEL_FILE}"
            )

        package = joblib.load(MODEL_FILE)
        if isinstance(package, dict):
            self.model = package["model"]
        else:
            self.model = package

        print("✅ Random Forest AI model loaded")
        print(f"Model: {MODEL_FILE}")

        os.makedirs("reports", exist_ok=True)

        self.previous_network = psutil.net_io_counters()

    # ---------------------------------------------------------
    # REAL PROCESSOR DATA
    # ---------------------------------------------------------

    def collect_metrics(self):

        cpu = psutil.cpu_percent(interval=0.5)

        memory = psutil.virtual_memory().percent

        frequency = psutil.cpu_freq()

        if frequency:

            current_freq = frequency.current
            min_freq = frequency.min
            max_freq = frequency.max

        else:

            current_freq = 0
            min_freq = 0
            max_freq = 0

        disk = psutil.disk_usage("/").percent

        process_count = len(
            psutil.pids()
        )

        cpu_count_physical = (
            psutil.cpu_count(logical=False) or 1
        )

        cpu_count_logical = (
            psutil.cpu_count(logical=True) or 1
        )

        network = psutil.net_io_counters()

        return {

            "CPU_Usage": round(cpu, 2),

            "Memory_Usage": round(
                memory,
                2
            ),

            "CPU_Frequency": round(
                current_freq,
                2
            ),

            "CPU_Min_Frequency": round(
                min_freq,
                2
            ),

            "CPU_Max_Frequency": round(
                max_freq,
                2
            ),

            "Physical_Cores":
                cpu_count_physical,

            "Logical_Cores":
                cpu_count_logical,

            "Process_Count":
                process_count,

            "Disk_Usage": round(
                disk,
                2
            ),

            "Network_Bytes_Sent":
                network.bytes_sent,

            "Network_Bytes_Received":
                network.bytes_recv
        }

    # ---------------------------------------------------------
    # AI PREDICTION
    # ---------------------------------------------------------

    def predict_workload(self, metrics):

        input_data = pd.DataFrame(
            [metrics],
            columns=FEATURES
        )

        prediction = self.model.predict(
            input_data
        )[0]

        probabilities = {}

        if hasattr(
            self.model,
            "predict_proba"
        ):

            values = self.model.predict_proba(
                input_data
            )[0]

            for label, probability in zip(
                self.model.classes_,
                values
            ):

                probabilities[str(label)] = (
                    float(probability) * 100
                )

        confidence = max(
            probabilities.values()
        ) if probabilities else 0

        return (
            prediction,
            probabilities,
            confidence
        )

    # ---------------------------------------------------------
    # AI DECISION ENGINE
    # ---------------------------------------------------------

    def make_decision(
        self,
        workload,
        metrics
    ):

        cpu = metrics["CPU_Usage"]
        memory = metrics["Memory_Usage"]

        # LOW WORKLOAD
        if workload == "LOW":

            mode = "POWER_EFFICIENT"

            recommendation = (
                "Reduce unnecessary background "
                "workloads and maintain an "
                "energy-efficient operating state."
            )

            action = (
                "Monitor background processes; "
                "avoid unnecessary CPU activity."
            )

        # MODERATE WORKLOAD
        elif workload == "MODERATE":

            mode = "BALANCED"

            recommendation = (
                "Maintain balanced processor "
                "utilization while preserving "
                "responsiveness."
            )

            action = (
                "Maintain current workload and "
                "monitor CPU and memory pressure."
            )

        # HIGH WORKLOAD
        else:

            mode = "PERFORMANCE"

            recommendation = (
                "Prioritize processor availability "
                "for the active workload."
            )

            action = (
                "Prioritize active workloads and "
                "monitor thermal/resource pressure."
            )

        # Additional safety observation

        if cpu > 80:

            action += (
                " High CPU utilization detected; "
                "continue monitoring thermal and "
                "system resource conditions."
            )

        if memory > 90:

            action += (
                " High memory utilization detected; "
                "identify unnecessary processes."
            )

        return (
            mode,
            recommendation,
            action
        )

    # ---------------------------------------------------------
    # SAVE AI DECISION
    # ---------------------------------------------------------

    def log_decision(
        self,
        metrics,
        workload,
        probabilities,
        confidence,
        mode,
        recommendation,
        action
    ):

        record = {

            "Timestamp":
                datetime.now().strftime(
                    "%Y-%m-%d %H:%M:%S"
                ),

            **metrics,

            "Predicted_Workload":
                workload,

            "AI_Confidence":
                round(
                    confidence,
                    2
                ),

            "AI_Mode":
                mode,

            "AI_Recommendation":
                recommendation,

            "AI_Action":
                action
        }

        df = pd.DataFrame(
            [record]
        )

        file_exists = os.path.exists(
            LOG_FILE
        )

        df.to_csv(
            LOG_FILE,
            mode="a",
            header=not file_exists,
            index=False
        )

    # ---------------------------------------------------------
    # ONE AI CYCLE
    # ---------------------------------------------------------

    def run_cycle(self):

        metrics = self.collect_metrics()

        workload, probabilities, confidence = (
            self.predict_workload(
                metrics
            )
        )

        mode, recommendation, action = (
            self.make_decision(
                workload,
                metrics
            )
        )

        self.log_decision(
            metrics,
            workload,
            probabilities,
            confidence,
            mode,
            recommendation,
            action
        )

        return {

            "metrics":
                metrics,

            "workload":
                workload,

            "probabilities":
                probabilities,

            "confidence":
                confidence,

            "mode":
                mode,

            "recommendation":
                recommendation,

            "action":
                action
        }


# -------------------------------------------------------------
# TEST AI ENGINE
# -------------------------------------------------------------

if __name__ == "__main__":

    engine = AIOptimizationEngine()

    print("\nStarting real-time AI analysis...\n")

    for i in range(10):

        result = engine.run_cycle()

        print(
            f"[{i + 1}/10] "
            f"CPU={result['metrics']['CPU_Usage']:.2f}% | "
            f"RAM={result['metrics']['Memory_Usage']:.2f}%"
        )

        print(
            f"AI Workload: "
            f"{result['workload']}"
        )

        print(
            f"Confidence: "
            f"{result['confidence']:.2f}%"
        )

        print(
            f"AI Mode: "
            f"{result['mode']}"
        )

        print(
            f"Recommendation: "
            f"{result['recommendation']}"
        )

        print("-" * 70)

        time.sleep(2)

    print("\n✅ AI OPTIMIZATION ENGINE COMPLETED")
    print(f"Decision log: {LOG_FILE}")