import psutil
import os
import time
import pandas as pd
from datetime import datetime

LOG_FILE = "reports/optimization_actions.csv"

os.makedirs("reports", exist_ok=True)


# ============================================================
# SYSTEM SNAPSHOT
# ============================================================

def get_system_snapshot():

    cpu = psutil.cpu_percent(interval=1)
    memory = psutil.virtual_memory().percent
    disk = psutil.disk_usage("/").percent

    frequency = psutil.cpu_freq()

    if frequency:
        cpu_frequency = frequency.current
    else:
        cpu_frequency = 0

    processes = len(psutil.pids())

    return {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "cpu_usage": round(cpu, 2),
        "memory_usage": round(memory, 2),
        "disk_usage": round(disk, 2),
        "cpu_frequency": round(cpu_frequency, 2),
        "process_count": processes
    }


# ============================================================
# FIND HIGH CPU PROCESSES
# ============================================================

def get_high_cpu_processes(threshold=20):

    processes = []

    for process in psutil.process_iter(
        ["pid", "name", "cpu_percent", "memory_percent"]
    ):

        try:

            cpu = process.info["cpu_percent"]

            if cpu is None:
                continue

            if cpu >= threshold:

                processes.append({
                    "PID": process.info["pid"],
                    "Process": process.info["name"],
                    "CPU": round(cpu, 2),
                    "Memory": round(
                        process.info["memory_percent"] or 0,
                        2
                    )
                })

        except (
            psutil.NoSuchProcess,
            psutil.AccessDenied,
            psutil.ZombieProcess
        ):

            continue

    return sorted(
        processes,
        key=lambda x: x["CPU"],
        reverse=True
    )


# ============================================================
# AI OPTIMIZATION DECISION
# ============================================================

def decide_optimization(workload, cpu, memory):

    if workload == "LOW":

        return {
            "mode": "POWER_EFFICIENT",
            "action": "MONITOR",
            "reason":
                "Low workload detected. No process intervention required."
        }

    elif workload == "MODERATE":

        return {
            "mode": "BALANCED",
            "action": "ANALYZE",
            "reason":
                "Moderate workload detected. Analyze resource-heavy processes."
        }

    elif workload == "HIGH":

        if cpu >= 80 or memory >= 85:

            return {
                "mode": "PERFORMANCE",
                "action": "IDENTIFY_HIGH_CPU",
                "reason":
                    "High workload and elevated resource usage detected."
            }

        return {
            "mode": "PERFORMANCE",
            "action": "ANALYZE",
            "reason":
                "High workload detected. Monitor resource-intensive processes."
        }

    return {
        "mode": "BALANCED",
        "action": "MONITOR",
        "reason":
            "System operating normally."
    }


# ============================================================
# SAFE PROCESS ANALYSIS
# ============================================================

def analyze_processes():

    processes = get_high_cpu_processes(
        threshold=20
    )

    return processes[:10]


# ============================================================
# LOG OPTIMIZATION ACTION
# ============================================================

def log_action(
    workload,
    decision,
    snapshot,
    processes
):

    rows = []

    if processes:

        for process in processes:

            rows.append({

                "Timestamp":
                    snapshot["timestamp"],

                "Workload":
                    workload,

                "AI_Mode":
                    decision["mode"],

                "AI_Action":
                    decision["action"],

                "CPU_Usage":
                    snapshot["cpu_usage"],

                "Memory_Usage":
                    snapshot["memory_usage"],

                "Process_Count":
                    snapshot["process_count"],

                "PID":
                    process["PID"],

                "Process_Name":
                    process["Process"],

                "Process_CPU":
                    process["CPU"],

                "Reason":
                    decision["reason"]
            })

    else:

        rows.append({

            "Timestamp":
                snapshot["timestamp"],

            "Workload":
                workload,

            "AI_Mode":
                decision["mode"],

            "AI_Action":
                decision["action"],

            "CPU_Usage":
                snapshot["cpu_usage"],

            "Memory_Usage":
                snapshot["memory_usage"],

            "Process_Count":
                snapshot["process_count"],

            "PID":
                "",

            "Process_Name":
                "",

            "Process_CPU":
                0,

            "Reason":
                decision["reason"]
        })

    df = pd.DataFrame(rows)

    if os.path.exists(LOG_FILE):

        df.to_csv(
            LOG_FILE,
            mode="a",
            header=False,
            index=False
        )

    else:

        df.to_csv(
            LOG_FILE,
            index=False
        )


# ============================================================
# RUN OPTIMIZATION CYCLE
# ============================================================

def optimization_cycle(workload):

    snapshot = get_system_snapshot()

    decision = decide_optimization(
        workload,
        snapshot["cpu_usage"],
        snapshot["memory_usage"]
    )

    processes = []

    if decision["action"] in [
        "IDENTIFY_HIGH_CPU",
        "ANALYZE"
    ]:

        processes = analyze_processes()

    log_action(
        workload,
        decision,
        snapshot,
        processes
    )

    return {
        "snapshot": snapshot,
        "decision": decision,
        "processes": processes
    }


# ============================================================
# TEST MODE
# ============================================================

if __name__ == "__main__":

    print("=" * 70)
    print("AI PROCESSOR OPTIMIZATION ENGINE")
    print("=" * 70)

    workload = input(
        "Enter AI workload (LOW/MODERATE/HIGH): "
    ).strip().upper()

    if workload not in [
        "LOW",
        "MODERATE",
        "HIGH"
    ]:

        workload = "LOW"

    result = optimization_cycle(workload)

    print("\nSYSTEM STATUS")
    print("-" * 50)

    for key, value in result["snapshot"].items():

        print(
            f"{key:20}: {value}"
        )

    print("\nAI DECISION")
    print("-" * 50)

    print(
        "Workload :",
        workload
    )

    print(
        "AI Mode  :",
        result["decision"]["mode"]
    )

    print(
        "Action   :",
        result["decision"]["action"]
    )

    print(
        "Reason   :",
        result["decision"]["reason"]
    )

    print("\nHIGH CPU PROCESSES")
    print("-" * 50)

    if result["processes"]:

        for process in result["processes"]:

            print(
                f"PID={process['PID']} | "
                f"{process['Process']} | "
                f"CPU={process['CPU']}%"
            )

    else:

        print("No high CPU processes detected.")

    print("\n✅ Optimization analysis completed.")

    print(
        f"Decision log saved to: {LOG_FILE}"
    )