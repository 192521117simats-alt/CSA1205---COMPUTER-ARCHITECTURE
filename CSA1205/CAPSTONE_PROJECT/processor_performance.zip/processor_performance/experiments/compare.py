import pandas as pd
import matplotlib.pyplot as plt
import os


BASELINE_FILE = "reports/baseline_results.csv"
OPTIMIZED_FILE = "reports/optimized_results.csv"

OUTPUT_DIR = "reports/graphs"

os.makedirs(OUTPUT_DIR, exist_ok=True)


print("=" * 70)
print("PROCESSOR PERFORMANCE COMPARISON")
print("=" * 70)


# ------------------------------------------------------------
# LOAD DATA
# ------------------------------------------------------------

baseline = pd.read_csv(BASELINE_FILE)
optimized = pd.read_csv(OPTIMIZED_FILE)


# ------------------------------------------------------------
# CALCULATE METRICS
# ------------------------------------------------------------

metrics = {
    "Average CPU Usage (%)": (
        baseline["CPU_Usage"].mean(),
        optimized["CPU_Usage"].mean()
    ),

    "Maximum CPU Usage (%)": (
        baseline["CPU_Usage"].max(),
        optimized["CPU_Usage"].max()
    ),

    "Average Memory Usage (%)": (
        baseline["Memory_Usage"].mean(),
        optimized["Memory_Usage"].mean()
    ),

    "Average CPU Frequency (MHz)": (
        baseline["CPU_Frequency"].mean(),
        optimized["CPU_Frequency"].mean()
    ),

    "Average Process Count": (
        baseline["Process_Count"].mean(),
        optimized["Process_Count"].mean()
    )
}


# ------------------------------------------------------------
# PRINT COMPARISON
# ------------------------------------------------------------

print("\n" + "=" * 70)
print("BEFORE vs AFTER COMPARISON")
print("=" * 70)

comparison_rows = []

for metric, values in metrics.items():

    before = values[0]
    after = values[1]

    if before != 0:

        percentage_change = (
            (after - before) / before
        ) * 100

    else:

        percentage_change = 0


    comparison_rows.append({

        "Metric": metric,

        "Baseline": round(before, 2),

        "AI-Assisted": round(after, 2),

        "Change (%)": round(
            percentage_change,
            2
        )
    })


    print(f"\n{metric}")

    print(f"Baseline   : {before:.2f}")

    print(f"AI-Assisted: {after:.2f}")

    print(
        f"Change     : "
        f"{percentage_change:+.2f}%"
    )


comparison_df = pd.DataFrame(
    comparison_rows
)


# ------------------------------------------------------------
# SAVE COMPARISON TABLE
# ------------------------------------------------------------

comparison_file = (
    "reports/performance_comparison.csv"
)

comparison_df.to_csv(
    comparison_file,
    index=False
)


print(
    f"\n✅ Comparison saved to: "
    f"{comparison_file}"
)


# ------------------------------------------------------------
# GRAPH 1 - CPU USAGE
# ------------------------------------------------------------

plt.figure(figsize=(10, 5))

plt.plot(
    baseline["CPU_Usage"],
    label="Baseline"
)

plt.plot(
    optimized["CPU_Usage"],
    label="AI-Assisted"
)

plt.xlabel("Measurement Sample")

plt.ylabel("CPU Usage (%)")

plt.title(
    "CPU Utilization: Baseline vs AI-Assisted Monitoring"
)

plt.legend()

plt.grid(True)

plt.tight_layout()

plt.savefig(
    f"{OUTPUT_DIR}/cpu_comparison.png",
    dpi=200
)

plt.close()


# ------------------------------------------------------------
# GRAPH 2 - MEMORY
# ------------------------------------------------------------

plt.figure(figsize=(10, 5))

plt.plot(
    baseline["Memory_Usage"],
    label="Baseline"
)

plt.plot(
    optimized["Memory_Usage"],
    label="AI-Assisted"
)

plt.xlabel("Measurement Sample")

plt.ylabel("Memory Usage (%)")

plt.title(
    "Memory Utilization: Baseline vs AI-Assisted"
)

plt.legend()

plt.grid(True)

plt.tight_layout()

plt.savefig(
    f"{OUTPUT_DIR}/memory_comparison.png",
    dpi=200
)

plt.close()


# ------------------------------------------------------------
# GRAPH 3 - CPU FREQUENCY
# ------------------------------------------------------------

plt.figure(figsize=(10, 5))

plt.plot(
    baseline["CPU_Frequency"],
    label="Baseline"
)

plt.plot(
    optimized["CPU_Frequency"],
    label="AI-Assisted"
)

plt.xlabel("Measurement Sample")

plt.ylabel("Frequency (MHz)")

plt.title(
    "CPU Frequency: Baseline vs AI-Assisted"
)

plt.legend()

plt.grid(True)

plt.tight_layout()

plt.savefig(
    f"{OUTPUT_DIR}/frequency_comparison.png",
    dpi=200
)

plt.close()


# ------------------------------------------------------------
# GRAPH 4 - PROCESS COUNT
# ------------------------------------------------------------

plt.figure(figsize=(10, 5))

plt.plot(
    baseline["Process_Count"],
    label="Baseline"
)

plt.plot(
    optimized["Process_Count"],
    label="AI-Assisted"
)

plt.xlabel("Measurement Sample")

plt.ylabel("Number of Processes")

plt.title(
    "System Process Count Comparison"
)

plt.legend()

plt.grid(True)

plt.tight_layout()

plt.savefig(
    f"{OUTPUT_DIR}/process_comparison.png",
    dpi=200
)

plt.close()


print("\n" + "=" * 70)
print("GRAPH GENERATION COMPLETED")
print("=" * 70)

print("\nGenerated graphs:")

print("✓ cpu_comparison.png")
print("✓ memory_comparison.png")
print("✓ frequency_comparison.png")
print("✓ process_comparison.png")

print("\nAll files are available in:")
print(OUTPUT_DIR)

print("\n✅ MODULE 3 PROCESSOR EVALUATION COMPLETED")