import psutil
import time
import pandas as pd
import os
import joblib
from datetime import datetime


# ============================================================
# MODULE 3 - AI-ASSISTED PROCESSOR OPTIMIZATION
# REAL-TIME OPTIMIZED EXPERIMENT
# ============================================================

SAMPLES = 60
INTERVAL = 1

MODEL_FILE = "models/workload_model.pkl"
OUTPUT_DIR = "reports"
OUTPUT_FILE = os.path.join(
    OUTPUT_DIR,
    "optimized_results.csv"
)


os.makedirs(OUTPUT_DIR, exist_ok=True)


print("=" * 70)
print("AI-ASSISTED PROCESSOR PERFORMANCE OPTIMIZATION")
print("MODULE 3 - OPTIMIZED PERFORMANCE TEST")
print("=" * 70)


# ============================================================
# 1. LOAD ML MODEL
# ============================================================

print("\nLoading trained ML model...")

package = joblib.load(MODEL_FILE)

model = package["model"]
features = package["features"]

print("✅ ML model loaded")


# ============================================================
# 2. SAFE SOFTWARE OPTIMIZATION
# ============================================================

print("\nApplying software-level optimization...")

# Clear Python process priority remains normal.
# We deliberately avoid changing Windows system power plans,
# CPU voltage, clock multiplier, or BIOS settings.

# Remove expired cache if applicable
try:
    import gc
    gc.collect()
except Exception:
    pass

print("✓ Python memory cleanup completed")
print("✓ Optimization monitoring enabled")
print("✓ Hardware clock/voltage settings left unchanged")


# ============================================================
# 3. REAL-TIME MONITORING
# ============================================================

data = []

print("\nStarting optimized monitoring...")
print(f"Samples: {SAMPLES}\n")


psutil.cpu_percent(interval=None)


for i in range(SAMPLES):

    start_time = time.perf_counter()

    cpu_usage = psutil.cpu_percent(interval=0.5)

    memory = psutil.virtual_memory()

    frequency = psutil.cpu_freq()

    if frequency:

        current_frequency = frequency.current
        min_frequency = frequency.min
        max_frequency = frequency.max

    else:

        current_frequency = 0
        min_frequency = 0
        max_frequency = 0


    process_count = len(psutil.pids())

    disk = psutil.disk_usage("C:")

    network = psutil.net_io_counters()

    measurement_time = (
        time.perf_counter() - start_time
    )


    # --------------------------------------------------------
    # ML INPUT
    # --------------------------------------------------------

    current_values = {}

    for feature in features:

        if feature == "CPU_Usage":
            current_values[feature] = cpu_usage

        elif feature == "Memory_Usage":
            current_values[feature] = memory.percent

        elif feature == "CPU_Frequency":
            current_values[feature] = current_frequency

        elif feature == "CPU_Min_Frequency":
            current_values[feature] = min_frequency

        elif feature == "CPU_Max_Frequency":
            current_values[feature] = max_frequency

        elif feature == "Physical_Cores":
            current_values[feature] = psutil.cpu_count(
                logical=False
            )

        elif feature == "Logical_Cores":
            current_values[feature] = psutil.cpu_count(
                logical=True
            )

        elif feature == "Process_Count":
            current_values[feature] = process_count

        elif feature == "Disk_Usage":
            current_values[feature] = disk.percent

        elif feature == "Network_Bytes_Sent":
            current_values[feature] = network.bytes_sent

        elif feature == "Network_Bytes_Received":
            current_values[feature] = network.bytes_recv


    ml_input = pd.DataFrame(
        [current_values],
        columns=features
    )


    prediction = model.predict(ml_input)[0]


    # --------------------------------------------------------
    # RECOMMENDATION
    # --------------------------------------------------------

    if prediction == "LOW":

        recommendation = "POWER_EFFICIENT"

    elif prediction == "MODERATE":

        recommendation = "BALANCED"

    elif prediction == "HIGH":

        recommendation = "PERFORMANCE"

    else:

        recommendation = "THERMAL_MONITOR"


    timestamp = datetime.now().strftime(
        "%Y-%m-%d %H:%M:%S"
    )


    data.append({

        "Timestamp": timestamp,

        "CPU_Usage": cpu_usage,

        "Memory_Usage": memory.percent,

        "CPU_Frequency": current_frequency,

        "CPU_Min_Frequency": min_frequency,

        "CPU_Max_Frequency": max_frequency,

        "Process_Count": process_count,

        "Disk_Usage": disk.percent,

        "Network_Bytes_Sent": network.bytes_sent,

        "Network_Bytes_Received":
            network.bytes_recv,

        "Workload_Prediction":
            prediction,

        "AI_Recommendation":
            recommendation,

        "Measurement_Time":
            measurement_time
    })


    print(
        f"[{i + 1:02d}/{SAMPLES}] "
        f"CPU={cpu_usage:5.1f}% | "
        f"RAM={memory.percent:5.1f}% | "
        f"Freq={current_frequency:7.1f} MHz | "
        f"ML={prediction:9s} | "
        f"Action={recommendation}"
    )


    time.sleep(INTERVAL)


# ============================================================
# 4. SAVE RESULTS
# ============================================================

df = pd.DataFrame(data)

df.to_csv(
    OUTPUT_FILE,
    index=False
)


# ============================================================
# 5. SUMMARY
# ============================================================

print("\n" + "=" * 70)
print("OPTIMIZED TEST COMPLETED")
print("=" * 70)

print(f"\nSaved to:")
print(OUTPUT_FILE)


print("\nOPTIMIZED PERFORMANCE SUMMARY")
print("-" * 50)

print(
    f"Average CPU Usage : "
    f"{df['CPU_Usage'].mean():.2f}%"
)

print(
    f"Maximum CPU Usage : "
    f"{df['CPU_Usage'].max():.2f}%"
)

print(
    f"Minimum CPU Usage : "
    f"{df['CPU_Usage'].min():.2f}%"
)

print(
    f"Average Memory    : "
    f"{df['Memory_Usage'].mean():.2f}%"
)

print(
    f"Average Frequency : "
    f"{df['CPU_Frequency'].mean():.2f} MHz"
)

print(
    f"Average Processes : "
    f"{df['Process_Count'].mean():.0f}"
)


print("\nML Workload Distribution:")

print(
    df["Workload_Prediction"]
    .value_counts()
)


print("\nAI Recommendations:")

print(
    df["AI_Recommendation"]
    .value_counts()
)


print("\n✅ Real-time AI-assisted monitoring completed.")