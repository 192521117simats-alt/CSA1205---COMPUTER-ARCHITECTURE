import psutil
import time
import pandas as pd
import os
from datetime import datetime


# ============================================================
# MODULE 3 - PROCESSOR EVALUATION
# REAL BASELINE PERFORMANCE EXPERIMENT
# ============================================================

SAMPLES = 60
INTERVAL = 1

OUTPUT_DIR = "../reports"
OUTPUT_FILE = os.path.join(OUTPUT_DIR, "baseline_results.csv")


os.makedirs(OUTPUT_DIR, exist_ok=True)


print("=" * 70)
print("AI-ASSISTED PROCESSOR PERFORMANCE OPTIMIZATION")
print("MODULE 3 - PROCESSOR EVALUATION")
print("BASELINE PERFORMANCE TEST")
print("=" * 70)

print("\nCollecting real processor performance data...")
print(f"Samples: {SAMPLES}")
print("Duration: approximately 60 seconds\n")


data = []


# Initial CPU measurement
psutil.cpu_percent(interval=None)


for i in range(SAMPLES):

    start_time = time.perf_counter()

    cpu_usage = psutil.cpu_percent(interval=0.5)

    memory = psutil.virtual_memory()

    frequency = psutil.cpu_freq()

    if frequency:

        current_frequency = frequency.current
        min_frequency = frequency.min
        max_frequency = frequency.max

    else:

        current_frequency = 0
        min_frequency = 0
        max_frequency = 0


    process_count = len(psutil.pids())

    disk = psutil.disk_usage("C:")

    network = psutil.net_io_counters()

    elapsed = time.perf_counter() - start_time

    timestamp = datetime.now().strftime(
        "%Y-%m-%d %H:%M:%S"
    )


    data.append({

        "Timestamp": timestamp,

        "CPU_Usage": cpu_usage,

        "Memory_Usage": memory.percent,

        "CPU_Frequency": current_frequency,

        "CPU_Min_Frequency": min_frequency,

        "CPU_Max_Frequency": max_frequency,

        "Process_Count": process_count,

        "Disk_Usage": disk.percent,

        "Network_Bytes_Sent": network.bytes_sent,

        "Network_Bytes_Received": network.bytes_recv,

        "Measurement_Time": elapsed
    })


    print(
        f"[{i + 1:02d}/{SAMPLES}] "
        f"CPU={cpu_usage:5.1f}% | "
        f"RAM={memory.percent:5.1f}% | "
        f"Freq={current_frequency:7.1f} MHz | "
        f"Processes={process_count}"
    )


    time.sleep(INTERVAL)


# ============================================================
# SAVE RESULTS
# ============================================================

df = pd.DataFrame(data)

df.to_csv(
    OUTPUT_FILE,
    index=False
)


# ============================================================
# PERFORMANCE SUMMARY
# ============================================================

print("\n" + "=" * 70)
print("BASELINE TEST COMPLETED")
print("=" * 70)

print(f"\nSaved to:")
print(OUTPUT_FILE)


print("\nPROCESSOR SUMMARY")
print("-" * 50)

print(
    f"Average CPU Usage : "
    f"{df['CPU_Usage'].mean():.2f}%"
)

print(
    f"Maximum CPU Usage : "
    f"{df['CPU_Usage'].max():.2f}%"
)

print(
    f"Minimum CPU Usage : "
    f"{df['CPU_Usage'].min():.2f}%"
)

print(
    f"Average Memory    : "
    f"{df['Memory_Usage'].mean():.2f}%"
)

print(
    f"Average Frequency : "
    f"{df['CPU_Frequency'].mean():.2f} MHz"
)

print(
    f"Maximum Frequency : "
    f"{df['CPU_Frequency'].max():.2f} MHz"
)

print(
    f"Average Processes : "
    f"{df['Process_Count'].mean():.0f}"
)


print("\n✅ Real baseline measurement completed.")