import os
import pandas as pd
import numpy as np
import joblib

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix
)

DATA_FILE = "ml_dataset.csv"
MODEL_DIR = "models"
MODEL_FILE = os.path.join(MODEL_DIR, "workload_model.pkl")


print("=" * 70)
print("AI-ASSISTED PROCESSOR PERFORMANCE OPTIMIZATION")
print("MODULE 2 - MACHINE LEARNING OPTIMIZATION")
print("=" * 70)


# ============================================================
# 1. LOAD DATA
# ============================================================

df = pd.read_csv(DATA_FILE)

print(f"\nTotal real samples: {len(df)}")


# ============================================================
# 2. FEATURES
# ============================================================

features = [
    "CPU_Usage",
    "Memory_Usage",
    "CPU_Frequency",
    "CPU_Min_Frequency",
    "CPU_Max_Frequency",
    "Physical_Cores",
    "Logical_Cores",
    "Process_Count",
    "Disk_Usage",
    "Network_Bytes_Sent",
    "Network_Bytes_Received"
]

# Keep only columns that actually exist
features = [f for f in features if f in df.columns]

print("\nFeatures used:")
for feature in features:
    print("  ✓", feature)


# ============================================================
# 3. CLEAN DATA
# ============================================================

X = df[features].copy()
y = df["Workload"].copy()

X = X.replace([np.inf, -np.inf], np.nan)

# Fill missing numerical values with median
X = X.fillna(X.median(numeric_only=True))


# ============================================================
# 4. DATA DISTRIBUTION
# ============================================================

print("\nWorkload distribution:")
print(y.value_counts())


# ============================================================
# 5. TRAIN / TEST SPLIT
# ============================================================

# Because MODERATE contains only 4 samples,
# stratification is unsafe for this dataset.

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=None
)

print("\nTraining samples:", len(X_train))
print("Testing samples :", len(X_test))


# ============================================================
# 6. TRAIN RANDOM FOREST
# ============================================================

model = RandomForestClassifier(
    n_estimators=150,
    random_state=42,
    class_weight="balanced",
    max_depth=10,
    min_samples_leaf=2
)

model.fit(X_train, y_train)

print("\n✅ Random Forest training completed.")


# ============================================================
# 7. PREDICTION
# ============================================================

y_pred = model.predict(X_test)


# ============================================================
# 8. EVALUATION
# ============================================================

accuracy = accuracy_score(y_test, y_pred)

print("\n" + "=" * 70)
print("MODEL EVALUATION")
print("=" * 70)

print(f"\nAccuracy: {accuracy * 100:.2f}%")

print("\nClassification Report:")

print(
    classification_report(
        y_test,
        y_pred,
        labels=["LOW", "MODERATE", "HIGH"],
        zero_division=0
    )
)

print("\nConfusion Matrix:")

labels = ["LOW", "MODERATE", "HIGH"]

cm = confusion_matrix(
    y_test,
    y_pred,
    labels=labels
)

print("Labels:", labels)
print(cm)


# ============================================================
# 9. FEATURE IMPORTANCE
# ============================================================

print("\n" + "=" * 70)
print("FEATURE IMPORTANCE")
print("=" * 70)

importance = model.feature_importances_

feature_importance = sorted(
    zip(features, importance),
    key=lambda x: x[1],
    reverse=True
)

for feature, value in feature_importance:
    print(f"{feature:30s} : {value:.4f}")


# ============================================================
# 10. SAVE MODEL
# ============================================================

os.makedirs(MODEL_DIR, exist_ok=True)

model_package = {
    "model": model,
    "features": features,
    "classes": list(model.classes_)
}

joblib.dump(model_package, MODEL_FILE)

print(f"\n✅ Model saved:")
print(MODEL_FILE)


# ============================================================
# 11. CURRENT SYSTEM PREDICTION
# ============================================================

latest = df.iloc[-1]

current_features = pd.DataFrame(
    [[latest[f] for f in features]],
    columns=features
)

current_prediction = model.predict(current_features)[0]

print("\n" + "=" * 70)
print("CURRENT PROCESSOR ANALYSIS")
print("=" * 70)

print(f"\nCPU Usage       : {latest['CPU_Usage']:.2f}%")
print(f"Memory Usage    : {latest['Memory_Usage']:.2f}%")
print(f"CPU Frequency   : {latest['CPU_Frequency']:.2f} MHz")
print(f"Process Count   : {latest['Process_Count']}")
print(f"Disk Usage      : {latest['Disk_Usage']:.2f}%")

print(f"\nPredicted Workload: {current_prediction}")


# ============================================================
# 12. PREDICTION PROBABILITIES
# ============================================================

probabilities = model.predict_proba(current_features)[0]

print("\nWorkload probabilities:")

for class_name, probability in zip(
    model.classes_,
    probabilities
):
    print(
        f"{class_name:10s}: "
        f"{probability * 100:.2f}%"
    )


# ============================================================
# 13. OPTIMIZATION RECOMMENDATION
# ============================================================

print("\n" + "=" * 70)
print("AI OPTIMIZATION RECOMMENDATION")
print("=" * 70)

if current_prediction == "LOW":

    recommendation = (
        "Power-efficient operation recommended. "
        "Avoid unnecessary background processes."
    )

elif current_prediction == "MODERATE":

    recommendation = (
        "Balanced operation recommended. "
        "Continue monitoring CPU and memory utilization."
    )

elif current_prediction == "HIGH":

    recommendation = (
        "Performance-oriented operation recommended. "
        "Monitor processor temperature and resource usage."
    )

else:

    recommendation = (
        "Very high processor workload detected. "
        "Monitor thermal conditions and system stability."
    )

print("\n→", recommendation)


print("\n" + "=" * 70)
print("MODULE 2 COMPLETED")
print("=" * 70)