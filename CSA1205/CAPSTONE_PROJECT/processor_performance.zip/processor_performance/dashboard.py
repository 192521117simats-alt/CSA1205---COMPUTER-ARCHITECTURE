import streamlit as st
import pandas as pd
import numpy as np
import psutil
import joblib
import os
import time
from datetime import datetime
import plotly.graph_objects as go


# ============================================================
# CONFIGURATION
# ============================================================

st.set_page_config(
    page_title="AI Processor Optimization System",
    page_icon="⚙️",
    layout="wide",
    initial_sidebar_state="expanded"
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

MODEL_FILE = os.path.join(
    BASE_DIR,
    "models",
    "workload_model.pkl"
)

AI_LOG_FILE = os.path.join(
    BASE_DIR,
    "reports",
    "ai_decision_log.csv"
)

OPTIMIZATION_LOG_FILE = os.path.join(
    BASE_DIR,
    "reports",
    "optimization_actions.csv"
)

os.makedirs(
    os.path.join(BASE_DIR, "reports"),
    exist_ok=True
)


# ============================================================
# CUSTOM CSS
# ============================================================

st.markdown("""
<style>

.main-title {
    font-size: 42px;
    font-weight: 800;
    text-align: center;
    margin-bottom: 5px;
}

.subtitle {
    text-align: center;
    color: #888888;
    font-size: 16px;
    margin-bottom: 30px;
}

.status-active {
    padding: 15px;
    border-radius: 10px;
    background-color: #143d2b;
    color: #54e69a;
    text-align: center;
    font-weight: bold;
}

.status-inactive {
    padding: 15px;
    border-radius: 10px;
    background-color: #402020;
    color: #ff7777;
    text-align: center;
    font-weight: bold;
}

.ai-box {
    padding: 18px;
    border-radius: 10px;
    background-color: #172d45;
    margin-top: 10px;
}

.warning-box {
    padding: 18px;
    border-radius: 10px;
    background-color: #4a3217;
    color: #ffd27a;
}

.success-box {
    padding: 18px;
    border-radius: 10px;
    background-color: #143d2b;
    color: #70e6a5;
}

</style>
""", unsafe_allow_html=True)


# ============================================================
# SESSION STATE
# ============================================================

if "monitoring" not in st.session_state:
    st.session_state.monitoring = False

if "history" not in st.session_state:
    st.session_state.history = []

if "model_loaded" not in st.session_state:
    st.session_state.model_loaded = False

if "model" not in st.session_state:
    st.session_state.model = None

if "model_features" not in st.session_state:
    st.session_state.model_features = [
        "CPU_Usage",
        "Memory_Usage",
        "CPU_Frequency",
        "CPU_Min_Frequency",
        "CPU_Max_Frequency",
        "Physical_Cores",
        "Logical_Cores",
        "Process_Count",
        "Disk_Usage",
        "Network_Bytes_Sent",
        "Network_Bytes_Received"
    ]


# ============================================================
# LOAD ML MODEL
# ============================================================

def load_model():

    if not os.path.exists(MODEL_FILE):
        return None

    try:

        package = joblib.load(MODEL_FILE)

        # Your model.py saved a dictionary
        if isinstance(package, dict):

            if "model" in package:
                model = package["model"]

            elif "classifier" in package:
                model = package["classifier"]

            elif "estimator" in package:
                model = package["estimator"]

            else:
                # Search dictionary values
                model = None

                for value in package.values():

                    if hasattr(value, "predict"):
                        model = value
                        break

                if model is None:
                    return None

            return model

        # Normal sklearn model
        if hasattr(package, "predict"):
            return package

        return None

    except Exception as e:

        st.error(
            f"Model loading error: {e}"
        )

        return None


# ============================================================
# SYSTEM INFORMATION
# ============================================================

def get_system_info():

    try:

        cpu_freq = psutil.cpu_freq()

        if cpu_freq:

            current_freq = cpu_freq.current
            min_freq = cpu_freq.min
            max_freq = cpu_freq.max

        else:

            current_freq = 0
            min_freq = 0
            max_freq = 0

        return {
            "Physical Cores": psutil.cpu_count(
                logical=False
            ),
            "Logical Cores": psutil.cpu_count(
                logical=True
            ),
            "CPU Frequency": current_freq,
            "Minimum Frequency": min_freq,
            "Maximum Frequency": max_freq
        }

    except Exception:

        return {
            "Physical Cores": 0,
            "Logical Cores": 0,
            "CPU Frequency": 0,
            "Minimum Frequency": 0,
            "Maximum Frequency": 0
        }


# ============================================================
# REAL-TIME SYSTEM METRICS
# ============================================================

def get_system_metrics():

    cpu_usage = psutil.cpu_percent(
        interval=0.2
    )

    memory_usage = psutil.virtual_memory().percent

    disk_usage = psutil.disk_usage(
        os.path.abspath(os.sep)
    ).percent

    cpu_freq = psutil.cpu_freq()

    if cpu_freq:

        frequency = cpu_freq.current
        min_frequency = cpu_freq.min
        max_frequency = cpu_freq.max

    else:

        frequency = 0
        min_frequency = 0
        max_frequency = 0

    physical_cores = psutil.cpu_count(
        logical=False
    )

    logical_cores = psutil.cpu_count(
        logical=True
    )

    process_count = len(
        list(psutil.process_iter())
    )

    network = psutil.net_io_counters()

    return {

        "Timestamp":
            datetime.now().strftime(
                "%H:%M:%S"
            ),

        "CPU_Usage":
            round(cpu_usage, 2),

        "Memory_Usage":
            round(memory_usage, 2),

        "CPU_Frequency":
            round(frequency, 2),

        "CPU_Min_Frequency":
            round(min_frequency, 2),

        "CPU_Max_Frequency":
            round(max_frequency, 2),

        "Physical_Cores":
            physical_cores,

        "Logical_Cores":
            logical_cores,

        "Process_Count":
            process_count,

        "Disk_Usage":
            round(disk_usage, 2),

        "Network_Bytes_Sent":
            network.bytes_sent,

        "Network_Bytes_Received":
            network.bytes_recv
    }


# ============================================================
# RESOURCE-INTENSIVE PROCESSES
# ============================================================

def get_resource_intensive_processes(
    threshold=5.0
):

    processes = []

    # First initialize process CPU counters
    process_objects = []

    for proc in psutil.process_iter(
        [
            "pid",
            "name",
            "memory_percent"
        ]
    ):

        try:

            proc.cpu_percent(
                interval=None
            )

            process_objects.append(proc)

        except (
            psutil.NoSuchProcess,
            psutil.AccessDenied,
            psutil.ZombieProcess
        ):
            continue

    # Small interval for actual CPU calculation
    time.sleep(0.15)

    for proc in process_objects:

        try:

            name = proc.info.get(
                "name"
            ) or "Unknown"

            # IMPORTANT:
            # Ignore Windows System Idle Process
            if name.lower() == "system idle process":
                continue

            cpu = proc.cpu_percent(
                interval=None
            )

            memory = proc.info.get(
                "memory_percent"
            ) or 0

            if cpu >= threshold:

                processes.append({

                    "PID":
                        proc.info["pid"],

                    "Process":
                        name,

                    "CPU %":
                        round(cpu, 2),

                    "Memory %":
                        round(memory, 2)
                })

        except (
            psutil.NoSuchProcess,
            psutil.AccessDenied,
            psutil.ZombieProcess
        ):
            continue

    processes.sort(
        key=lambda x: x["CPU %"],
        reverse=True
    )

    return processes[:10]


# ============================================================
# ML PREDICTION
# ============================================================

def predict_workload(metrics):

    model = st.session_state.model

    if model is None:

        return (
            "UNKNOWN",
            0.0,
            {
                "LOW": 0,
                "MODERATE": 0,
                "HIGH": 0
            }
        )

    feature_names = (
        st.session_state.model_features
    )

    values = []

    for feature in feature_names:

        values.append(
            metrics.get(
                feature,
                0
            )
        )

    X = pd.DataFrame(
        [values],
        columns=feature_names
    )

    try:

        prediction = model.predict(X)

        workload = str(
            prediction[0]
        ).upper()

        probabilities = {
            "LOW": 0,
            "MODERATE": 0,
            "HIGH": 0
        }

        confidence = 0

        if hasattr(
            model,
            "predict_proba"
        ):

            probability_values = (
                model.predict_proba(X)[0]
            )

            classes = list(
                model.classes_
            )

            for cls, probability in zip(
                classes,
                probability_values
            ):

                cls_name = str(
                    cls
                ).upper()

                probabilities[
                    cls_name
                ] = round(
                    probability * 100,
                    2
                )

            confidence = max(
                probability_values
            ) * 100

        else:

            confidence = 100

        return (
            workload,
            round(confidence, 2),
            probabilities
        )

    except Exception as e:

        return (
            "UNKNOWN",
            0,
            {
                "LOW": 0,
                "MODERATE": 0,
                "HIGH": 0
            }
        )


# ============================================================
# AI DECISION ENGINE
# ============================================================

def ai_decision(
    workload,
    cpu_usage,
    memory_usage
):

    workload = workload.upper()

    if workload == "HIGH":

        mode = "PERFORMANCE"

        action = "OPTIMIZE"

        recommendation = (
            "High workload detected. "
            "Prioritize processor performance "
            "and monitor resource-intensive processes."
        )

    elif workload == "MODERATE":

        mode = "BALANCED"

        action = "BALANCE"

        recommendation = (
            "Moderate workload detected. "
            "Maintain balanced processor operation "
            "while monitoring CPU and memory usage."
        )

    elif workload == "LOW":

        mode = "POWER_EFFICIENT"

        action = "MONITOR"

        recommendation = (
            "Low workload detected. "
            "Maintain energy-efficient operation "
            "and reduce unnecessary background workloads."
        )

    else:

        mode = "MONITOR"

        action = "MONITOR"

        recommendation = (
            "Unable to determine workload. "
            "Continue monitoring system resources."
        )

    # Additional real-time CPU condition
    if cpu_usage >= 80:

        action = "HIGH_CPU_ALERT"

        recommendation = (
            "CPU utilization is critically high. "
            "Inspect resource-intensive processes."
        )

    elif memory_usage >= 90:

        action = "MEMORY_ALERT"

        recommendation = (
            "Memory utilization is critically high. "
            "Inspect memory-intensive processes."
        )

    return (
        mode,
        action,
        recommendation
    )


# ============================================================
# SAVE AI LOG
# ============================================================

def save_ai_log(
    metrics,
    workload,
    confidence,
    mode,
    action,
    recommendation
):

    row = {

        "Timestamp":
            datetime.now().strftime(
                "%Y-%m-%d %H:%M:%S"
            ),

        "CPU_Usage":
            metrics["CPU_Usage"],

        "Memory_Usage":
            metrics["Memory_Usage"],

        "CPU_Frequency":
            metrics["CPU_Frequency"],

        "Process_Count":
            metrics["Process_Count"],

        "Disk_Usage":
            metrics["Disk_Usage"],

        "Workload":
            workload,

        "Confidence":
            round(confidence, 2),

        "AI_Mode":
            mode,

        "AI_Action":
            action,

        "Recommendation":
            recommendation
    }

    try:

        if os.path.exists(
            AI_LOG_FILE
        ):

            df = pd.read_csv(
                AI_LOG_FILE
            )

            df = pd.concat(
                [
                    df,
                    pd.DataFrame([row])
                ],
                ignore_index=True
            )

        else:

            df = pd.DataFrame(
                [row]
            )

        df.to_csv(
            AI_LOG_FILE,
            index=False
        )

    except Exception:
        pass


# ============================================================
# SAVE OPTIMIZATION ACTION
# ============================================================

def save_optimization_action(
    metrics,
    workload,
    confidence,
    mode,
    action,
    recommendation
):

    row = {

        "Timestamp":
            datetime.now().strftime(
                "%Y-%m-%d %H:%M:%S"
            ),

        "Workload":
            workload,

        "Confidence":
            round(confidence, 2),

        "AI_Mode":
            mode,

        "Action":
            action,

        "CPU_Usage":
            metrics["CPU_Usage"],

        "Memory_Usage":
            metrics["Memory_Usage"],

        "CPU_Frequency":
            metrics["CPU_Frequency"],

        "Process_Count":
            metrics["Process_Count"],

        "Recommendation":
            recommendation
    }

    try:

        if os.path.exists(
            OPTIMIZATION_LOG_FILE
        ):

            df = pd.read_csv(
                OPTIMIZATION_LOG_FILE
            )

            df = pd.concat(
                [
                    df,
                    pd.DataFrame([row])
                ],
                ignore_index=True
            )

        else:

            df = pd.DataFrame(
                [row]
            )

        df.to_csv(
            OPTIMIZATION_LOG_FILE,
            index=False
        )

    except Exception:
        pass


# ============================================================
# LOAD MODEL
# ============================================================

if not st.session_state.model_loaded:

    loaded_model = load_model()

    if loaded_model is not None:

        st.session_state.model = (
            loaded_model
        )

        st.session_state.model_loaded = True


# ============================================================
# SIDEBAR
# ============================================================

with st.sidebar:

    st.header("⚙️ Control Panel")

    interval = st.slider(
        "Monitoring Interval (seconds)",
        min_value=1,
        max_value=10,
        value=2
    )

    st.write("")

    if st.button(
        "▶ Start Monitoring",
        use_container_width=True
    ):

        st.session_state.monitoring = True

    if st.button(
        "⏹ Stop Monitoring",
        use_container_width=True
    ):

        st.session_state.monitoring = False

    if st.button(
        "🔄 Refresh",
        use_container_width=True
    ):

        st.rerun()

    st.divider()

    if st.session_state.model_loaded:

        st.success(
            "🟢 ML Model Loaded"
        )

    else:

        st.error(
            "🔴 ML Model Not Loaded"
        )

    if os.path.exists(
        AI_LOG_FILE
    ):

        st.success(
            "🟢 AI Optimization Log Active"
        )

    else:

        st.warning(
            "🟡 AI Log Waiting"
        )

    st.divider()

    st.subheader(
        "System Information"
    )

    system_info = get_system_info()

    st.write(
        f"Physical Cores: "
        f"{system_info['Physical Cores']}"
    )

    st.write(
        f"Logical Cores: "
        f"{system_info['Logical Cores']}"
    )

    st.write(
        f"CPU Frequency: "
        f"{system_info['CPU Frequency']:.1f} MHz"
    )


# ============================================================
# TITLE
# ============================================================

st.markdown(
    '<div class="main-title">'
    '⚙️ AI-Assisted Processor '
    'Performance Optimization'
    '</div>',
    unsafe_allow_html=True
)

st.markdown(
    '<div class="subtitle">'
    'Real-Time Monitoring • Machine Learning • '
    'AI Decision Engine • Optimization Analysis'
    '</div>',
    unsafe_allow_html=True
)


# ============================================================
# STATUS
# ============================================================

if st.session_state.monitoring:

    st.markdown(
        '<div class="status-active">'
        '🟢 REAL-TIME MONITORING SYSTEM ACTIVE'
        '</div>',
        unsafe_allow_html=True
    )

else:

    st.markdown(
        '<div class="status-inactive">'
        '🔴 MONITORING STOPPED — CLICK START MONITORING'
        '</div>',
        unsafe_allow_html=True
    )


st.write("")


# ============================================================
# GET CURRENT METRICS
# ============================================================

metrics = get_system_metrics()

workload, confidence, probabilities = (
    predict_workload(metrics)
)

mode, action, recommendation = ai_decision(
    workload,
    metrics["CPU_Usage"],
    metrics["Memory_Usage"]
)


# ============================================================
# SAVE DATA
# ============================================================

if st.session_state.monitoring:

    history_record = {
        **metrics,
        "Workload": workload,
        "Confidence": confidence
    }

    st.session_state.history.append(
        history_record
    )

    # Keep last 60 samples
    if len(
        st.session_state.history
    ) > 60:

        st.session_state.history = (
            st.session_state.history[-60:]
        )

    save_ai_log(
        metrics,
        workload,
        confidence,
        mode,
        action,
        recommendation
    )

    save_optimization_action(
        metrics,
        workload,
        confidence,
        mode,
        action,
        recommendation
    )


# ============================================================
# REAL-TIME PROCESSOR STATUS
# ============================================================

st.header(
    "📊 Real-Time Processor Status"
)

c1, c2, c3, c4, c5 = st.columns(5)

with c1:

    st.metric(
        "CPU Usage",
        f"{metrics['CPU_Usage']:.1f}%"
    )

with c2:

    st.metric(
        "Memory Usage",
        f"{metrics['Memory_Usage']:.1f}%"
    )

with c3:

    st.metric(
        "CPU Frequency",
        f"{metrics['CPU_Frequency']:.1f} MHz"
    )

with c4:

    st.metric(
        "Processes",
        metrics["Process_Count"]
    )

with c5:

    st.metric(
        "Disk Usage",
        f"{metrics['Disk_Usage']:.1f}%"
    )


st.divider()


# ============================================================
# AI WORKLOAD ANALYSIS
# ============================================================

st.header(
    "🤖 AI Workload Analysis"
)

a1, a2, a3 = st.columns(3)

with a1:

    if workload == "LOW":

        st.success(
            f"🟢 LOW WORKLOAD\n\n"
            f"{confidence:.2f}% confidence"
        )

    elif workload == "MODERATE":

        st.warning(
            f"🟡 MODERATE WORKLOAD\n\n"
            f"{confidence:.2f}% confidence"
        )

    elif workload == "HIGH":

        st.error(
            f"🔴 HIGH WORKLOAD\n\n"
            f"{confidence:.2f}% confidence"
        )

    else:

        st.info(
            "UNKNOWN WORKLOAD"
        )


with a2:

    st.info(
        f"**AI MODE**\n\n"
        f"### {mode}"
    )


with a3:

    st.info(
        f"**AI ACTION**\n\n"
        f"### {action}"
    )


if workload == "HIGH":

    st.markdown(
        f'<div class="warning-box">'
        f'💡 <b>AI Optimization Recommendation</b><br><br>'
        f'{recommendation}'
        f'</div>',
        unsafe_allow_html=True
    )

else:

    st.markdown(
        f'<div class="ai-box">'
        f'💡 <b>AI Optimization Recommendation</b><br><br>'
        f'{recommendation}'
        f'</div>',
        unsafe_allow_html=True
    )


st.write("")


# ============================================================
# WORKLOAD PROBABILITIES
# ============================================================

st.header(
    "🎯 AI Workload Probability"
)

prob_df = pd.DataFrame({

    "Workload": [
        "LOW",
        "MODERATE",
        "HIGH"
    ],

    "Probability": [
        probabilities.get(
            "LOW",
            0
        ),
        probabilities.get(
            "MODERATE",
            0
        ),
        probabilities.get(
            "HIGH",
            0
        )
    ]
})


fig_prob = go.Figure()

fig_prob.add_trace(
    go.Bar(
        x=prob_df["Workload"],
        y=prob_df["Probability"],
        text=[
            f"{x:.2f}%"
            for x in prob_df["Probability"]
        ],
        textposition="auto"
    )
)

fig_prob.update_layout(
    yaxis_title="Probability (%)",
    xaxis_title="Workload",
    yaxis=dict(
        range=[
            0,
            100
        ]
    ),
    height=350
)

st.plotly_chart(
    fig_prob,
    use_container_width=True
)


# ============================================================
# REAL-TIME PERFORMANCE GRAPH
# ============================================================

st.header(
    "📈 Real-Time Performance"
)

if len(
    st.session_state.history
) >= 2:

    history_df = pd.DataFrame(
        st.session_state.history
    )

    fig = go.Figure()

    fig.add_trace(
        go.Scatter(
            x=history_df["Timestamp"],
            y=history_df["CPU_Usage"],
            mode="lines+markers",
            name="CPU Usage (%)"
        )
    )

    fig.add_trace(
        go.Scatter(
            x=history_df["Timestamp"],
            y=history_df["Memory_Usage"],
            mode="lines+markers",
            name="Memory Usage (%)"
        )
    )

    fig.update_layout(
        xaxis_title="Time",
        yaxis_title="Usage (%)",
        height=400,
        hovermode="x unified"
    )

    st.plotly_chart(
        fig,
        use_container_width=True
    )

else:

    st.info(
        "Start monitoring to collect "
        "real-time performance data."
    )


# ============================================================
# RESOURCE-INTENSIVE PROCESSES
# ============================================================

st.header(
    "🔥 Resource-Intensive Processes"
)

processes = get_resource_intensive_processes(
    threshold=5.0
)

if processes:

    process_df = pd.DataFrame(
        processes
    )

    st.dataframe(
        process_df,
        use_container_width=True,
        hide_index=True
    )

else:

    st.info(
        "No resource-intensive processes "
        "detected above the 5% CPU threshold."
    )


# ============================================================
# AI OPTIMIZATION ACTIONS
# ============================================================

st.header(
    "⚙️ AI Optimization Actions"
)

o1, o2, o3 = st.columns(3)

with o1:

    st.metric(
        "Workload",
        workload
    )

with o2:

    st.metric(
        "AI Confidence",
        f"{confidence:.2f}%"
    )

with o3:

    st.metric(
        "AI Action",
        action
    )


# ============================================================
# RECENT AI LOG
# ============================================================

st.subheader(
    "📋 Latest AI Decisions"
)

if os.path.exists(
    AI_LOG_FILE
):

    try:

        log_df = pd.read_csv(
            AI_LOG_FILE
        )

        if not log_df.empty:

            st.dataframe(
                log_df.tail(10),
                use_container_width=True,
                hide_index=True
            )

        else:

            st.info(
                "AI decision log is empty."
            )

    except Exception as e:

        st.warning(
            f"Could not read AI log: {e}"
        )

else:

    st.info(
        "No AI decisions logged yet."
    )


# ============================================================
# OPTIMIZATION ACTION LOG
# ============================================================

st.subheader(
    "🔧 Optimization Action Log"
)

if os.path.exists(
    OPTIMIZATION_LOG_FILE
):

    try:

        optimization_df = pd.read_csv(
            OPTIMIZATION_LOG_FILE
        )

        if not optimization_df.empty:

            st.dataframe(
                optimization_df.tail(10),
                use_container_width=True,
                hide_index=True
            )

        else:

            st.info(
                "Optimization log is empty."
            )

    except Exception as e:

        st.warning(
            f"Could not read optimization log: {e}"
        )

else:

    st.info(
        "Optimization actions will appear "
        "after monitoring starts."
    )


# ============================================================
# SYSTEM SUMMARY
# ============================================================

st.divider()

st.header(
    "🖥️ Current System Summary"
)

s1, s2, s3, s4 = st.columns(4)

with s1:

    st.metric(
        "Physical Cores",
        system_info["Physical Cores"]
    )

with s2:

    st.metric(
        "Logical Cores",
        system_info["Logical Cores"]
    )

with s3:

    st.metric(
        "Current Frequency",
        f"{metrics['CPU_Frequency']:.1f} MHz"
    )

with s4:

    st.metric(
        "Monitoring Samples",
        len(
            st.session_state.history
        )
    )


# ============================================================
# AUTO REFRESH
# ============================================================

if st.session_state.monitoring:

    time.sleep(
        interval
    )

    st.rerun()