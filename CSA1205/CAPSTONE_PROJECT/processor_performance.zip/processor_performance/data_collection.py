import psutil
import time
import pandas as pd
from datetime import datetime

data = []

SAMPLES = 300
INTERVAL = 1

print("=" * 60)
print("AI-ASSISTED PROCESSOR PERFORMANCE OPTIMIZATION")
print("REAL-TIME PERFORMANCE DATA COLLECTION")
print("=" * 60)

print(f"Collecting {SAMPLES} real measurements...")
print("Press Ctrl+C to stop.\n")

try:
    for i in range(SAMPLES):

        # REAL CPU utilization
        cpu = psutil.cpu_percent(interval=0.5)

        # REAL memory utilization
        memory = psutil.virtual_memory().percent

        # REAL CPU frequency
        frequency_info = psutil.cpu_freq()

        if frequency_info:
            frequency = frequency_info.current
            min_frequency = frequency_info.min
            max_frequency = frequency_info.max
        else:
            frequency = None
            min_frequency = None
            max_frequency = None

        # REAL CPU information
        physical_cores = psutil.cpu_count(logical=False)
        logical_cores = psutil.cpu_count(logical=True)

        # REAL process count
        process_count = len(psutil.pids())

        # REAL disk usage
        disk = psutil.disk_usage("C:")
        disk_used = disk.percent

        # REAL network counters
        network = psutil.net_io_counters()
        bytes_sent = network.bytes_sent
        bytes_received = network.bytes_recv

        # Timestamp
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        data.append([
            timestamp,
            cpu,
            memory,
            frequency,
            min_frequency,
            max_frequency,
            physical_cores,
            logical_cores,
            process_count,
            disk_used,
            bytes_sent,
            bytes_received
        ])

        print(
            f"[{i + 1:03d}/{SAMPLES}] "
            f"CPU={cpu:5.1f}% | "
            f"RAM={memory:5.1f}% | "
            f"Freq={frequency if frequency else 'N/A'} MHz | "
            f"Processes={process_count}"
        )

        time.sleep(INTERVAL)

except KeyboardInterrupt:
    print("\n\n⚠ Collection stopped by user.")

# Create DataFrame
columns = [
    "Timestamp",
    "CPU_Usage",
    "Memory_Usage",
    "CPU_Frequency",
    "CPU_Min_Frequency",
    "CPU_Max_Frequency",
    "Physical_Cores",
    "Logical_Cores",
    "Process_Count",
    "Disk_Usage",
    "Network_Bytes_Sent",
    "Network_Bytes_Received"
]

df = pd.DataFrame(data, columns=columns)

# Save real data
df.to_csv("cpu_data.csv", index=False)

print("\n" + "=" * 60)
print("DATA COLLECTION COMPLETE")
print("=" * 60)
print(f"Real samples collected : {len(df)}")
print("File saved             : cpu_data.csv")

print("\nDataset summary:")
print(df.describe(include="all"))
