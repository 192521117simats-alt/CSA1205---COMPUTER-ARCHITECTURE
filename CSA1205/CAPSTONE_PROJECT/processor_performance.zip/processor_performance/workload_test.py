import psutil
import time
import pandas as pd
from datetime import datetime
from multiprocessing import Process, cpu_count


SAMPLES = 120
INTERVAL = 1


def cpu_worker():
    """
    Generates a controlled CPU workload.
    The workload is performed on the actual processor.
    """
    end_time = time.time() + (SAMPLES + 5)

    value = 0

    while time.time() < end_time:
        value = (value * 3 + 7) % 10000019


def collect_data():

    data = []

    print("=" * 65)
    print("CONTROLLED REAL CPU WORKLOAD EXPERIMENT")
    print("=" * 65)

    print(f"\nCollecting {SAMPLES} measurements...")
    print("CPU workload will run on the actual processor.")
    print("Do not run games or heavy applications during the test.\n")

    workers = max(1, cpu_count() // 2)

    processes = []

    try:

        for _ in range(workers):
            p = Process(target=cpu_worker)
            p.start()
            processes.append(p)

        for i in range(SAMPLES):

            cpu = psutil.cpu_percent(interval=0.5)
            memory = psutil.virtual_memory().percent

            frequency_info = psutil.cpu_freq()

            if frequency_info:
                frequency = frequency_info.current
                min_frequency = frequency_info.min
                max_frequency = frequency_info.max
            else:
                frequency = None
                min_frequency = None
                max_frequency = None

            physical_cores = psutil.cpu_count(logical=False)
            logical_cores = psutil.cpu_count(logical=True)

            process_count = len(psutil.pids())

            disk = psutil.disk_usage("C:")
            disk_used = disk.percent

            network = psutil.net_io_counters()

            timestamp = datetime.now().strftime(
                "%Y-%m-%d %H:%M:%S"
            )

            data.append([
                timestamp,
                cpu,
                memory,
                frequency,
                min_frequency,
                max_frequency,
                physical_cores,
                logical_cores,
                process_count,
                disk_used,
                network.bytes_sent,
                network.bytes_recv
            ])

            print(
                f"[{i+1:03d}/{SAMPLES}] "
                f"CPU={cpu:5.1f}% | "
                f"RAM={memory:5.1f}% | "
                f"Freq={frequency if frequency else 'N/A'} MHz"
            )

            time.sleep(INTERVAL)

    finally:

        print("\nStopping CPU workload...")

        for p in processes:
            p.terminate()

        for p in processes:
            p.join()

    columns = [
        "Timestamp",
        "CPU_Usage",
        "Memory_Usage",
        "CPU_Frequency",
        "CPU_Min_Frequency",
        "CPU_Max_Frequency",
        "Physical_Cores",
        "Logical_Cores",
        "Process_Count",
        "Disk_Usage",
        "Network_Bytes_Sent",
        "Network_Bytes_Received"
    ]

    df = pd.DataFrame(data, columns=columns)

    df.to_csv("workload_data.csv", index=False)

    print("\n" + "=" * 65)
    print("WORKLOAD EXPERIMENT COMPLETE")
    print("=" * 65)

    print(f"Samples collected: {len(df)}")
    print("Saved as: workload_data.csv")

    print("\nCPU statistics:")
    print(df["CPU_Usage"].describe())


if __name__ == "__main__":
    collect_data()