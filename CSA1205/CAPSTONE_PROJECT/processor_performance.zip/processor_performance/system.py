import psutil
import time
import random

print("🚀 Real-Time Processor Optimization System Started...\n")

while True:
    cpu = psutil.cpu_percent()
    memory = psutil.virtual_memory().percent
    freq = psutil.cpu_freq().current

    # REAL DECISION LOGIC (not ML, actual system logic)
    if cpu > 75:
        decision = "⚠️ High Load → Increase Performance Mode"
        optimized_freq = freq + 200
    elif cpu < 30:
        decision = "💡 Low Load → Power Saving Mode"
        optimized_freq = freq - 200
    else:
        decision = "✅ Balanced Mode"
        optimized_freq = freq

    print(f"""
-------------------------------
CPU Usage     : {cpu} %
Memory Usage  : {memory} %
Current Freq  : {freq} MHz
-------------------------------
Decision      : {decision}
Suggested Freq: {optimized_freq} MHz
-------------------------------
""")

    time.sleep(2)